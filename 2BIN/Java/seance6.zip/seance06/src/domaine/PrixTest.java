package domaine;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import exceptions.QuantiteNonAutoriseeException;

class PrixTest {

	private Prix prixAucune;
	private Prix prixPub;
	private Prix prixSolde;
	
	@BeforeEach
	void setUp() throws Exception {
		prixAucune = new Prix();
		prixPub = new Prix(Promo.PUB, 20);
		prixSolde = new Prix(Promo.SOLDE, 20);
		
		prixAucune.definirPrix(1, 20);
		prixAucune.definirPrix(10, 10);
		
		prixPub.definirPrix(3, 15);
		
	}
	
	@DisplayName("Test du constructeur avec promo en param�tre une promo null")
	@Test
	void testPrixPromoNull() {
		
		assertThrows(IllegalArgumentException.class, () -> new Prix(null, 10));
	}
	
	@DisplayName("Test du constructeur avec valeur en param�tre n�gatif")
	@Test
	void testPrixValeurNegative() {
		
		 assertThrows(IllegalArgumentException.class, () -> new Prix(Promo.PUB, -8));
	}
	
	@DisplayName("Test des getters")
	@Test
	void testPrixPromoDouble() {
		assertAll(
					() -> assertEquals(0, prixAucune.getValeurPromo()),
					() -> assertEquals(20, prixPub.getValeurPromo()),
					() -> assertEquals(null, prixAucune.getTypePromo()),
					() -> assertEquals(Promo.SOLDE, prixSolde.getTypePromo())
				);
	}
	
	@DisplayName("Test Definir prix")
	@Test
	void testDefinirPrix() {
		prixAucune.definirPrix(6, 10);
		assertAll(
					() -> assertThrows(IllegalArgumentException.class, () -> prixPub.definirPrix(0, 10)),
					() -> assertThrows(IllegalArgumentException.class, () -> prixPub.definirPrix(-8, 10)),
					() -> assertThrows(IllegalArgumentException.class, () -> prixPub.definirPrix(1, 0)),
					() -> assertThrows(IllegalArgumentException.class, () -> prixPub.definirPrix(1, -9)),
					() -> assertEquals(10, prixAucune.getPrix(6))
				);
	}
	
	@DisplayName("Test Get Prix o� la valeur est n�gatif ou 0")
	@ParameterizedTest
	@ValueSource(ints = {-8, 0})
	void testGetPrixWhereValueIsEqualTo0orNegatif(int value) {
		assertThrows(IllegalArgumentException.class, () -> prixPub.getPrix(value));
	}
	
	@DisplayName("Test get Prix o� les prix renvoy� sont bon")
	@ParameterizedTest
	@ValueSource(ints = {1, 5, 9, 10, 15, 20, 25})
	void testGetPrixWhereValueIsGood(int unite) throws QuantiteNonAutoriseeException {
		prixSolde.definirPrix(1, 20);
		assertEquals(20, prixSolde.getPrix(unite));
	}

	
	@DisplayName("GetPrix : Demande le prix pour 2 unit� de prixPub : Exception")
	@Test
	void testGetPrixWhereIsNotGood() {
		assertThrows(QuantiteNonAutoriseeException.class, () -> prixPub.getPrix(2));
	}
	
	@DisplayName("GetPrix : Demande le prix pour 1 unit� de prixSolde : Exception")
	@Test
	void testGetPrixWhereQuantiteIsNotGood() {
		assertThrows(QuantiteNonAutoriseeException.class, () -> prixSolde.getPrix(1));
	}
	

	@DisplayName("Test du clone de l'objet")
	@Test
	void testClone() {
		assertNotSame(prixAucune, prixAucune.clone());
	}
	
	@DisplayName("Test attributs sont les m�mes que le clone")
	@Test
	void testCloneAttributs() {
		assertAll(
					() -> assertSame(prixPub.getTypePromo(), prixPub.clone().getTypePromo()),
					() -> assertEquals(prixPub.getValeurPromo(), prixPub.clone().getValeurPromo())
				);
	}
	
	@DisplayName("Test les valeurs du clone sont les m�mes")
	@ParameterizedTest
	@ValueSource(ints = {1,2,5,10})
	void testCloneValue(int quantite) throws QuantiteNonAutoriseeException {
		assertEquals(prixAucune.getPrix(quantite), prixAucune.clone().getPrix(quantite));
		
	}

}
