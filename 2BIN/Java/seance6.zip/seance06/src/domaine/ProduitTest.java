package domaine;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.time.Month;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import exceptions.DateDejaPresenteException;
import exceptions.PrixNonDisponibleException;

class ProduitTest {
	
	private Produit produit1;
	private Produit produit2;
	private Prix prixAucune;
	private LocalDate date;
	
	@BeforeEach
	void setUp() throws Exception {
		
		prixAucune = new Prix();
		
		prixAucune.definirPrix(1, 20);
		prixAucune.definirPrix(10, 10);
		
		date = LocalDate.of(2019, Month.DECEMBER, 25);
		
		produit1 = new Produit("Chocolat", "Nutella", "Nourriture");
		produit1.ajouterPrix(date, prixAucune);
		
		produit2 = new Produit("Biscuit", "Neslea", "Collation");
	
		
	}

	@Test
	void testHashCode() {
		fail("Not yet implemented");
	}

	@DisplayName("Test du constructeur quand un param�tre est mauvais")
	@Test
	void testProduit() {
		assertAll(
					() -> assertThrows(IllegalArgumentException.class, () -> new Produit("test", null, "test")),
					() -> assertThrows(IllegalArgumentException.class, () -> new Produit("    ", null, "test"))
				);
	}
	
	@DisplayName("Test du param�tre Marque pass� dans le constructeur")
	@Test
	void testGetMarque() {
		assertEquals("Chocolat", produit1.getMarque());
	}

	@DisplayName("Test du param�tre nom pass� dans le constructeur")
	@Test
	void testGetNom() {
		assertEquals("Chocolat", produit1.getNom());
	}

	@DisplayName("Test du param�tre rayon pass� dans le constructeur")
	@Test
	void testGetRayon() {
		assertEquals("Chocolat", produit1.getRayon());
	}

	@DisplayName("Test AjouterPrix renvoie une IllegalArgumentException")
	@Test
	void testAjouterPrixIllegalArgumentException() {
		assertThrows(IllegalArgumentException.class, () -> produit2.ajouterPrix(null, prixAucune));
	}
	
	@DisplayName("Test AjouterPrix renvoie une DateDejaPresenteException")
	@Test
	void testAjouterPrixDateDejaPresenteException() {
		assertThrows(DateDejaPresenteException.class, () -> produit1.ajouterPrix(date, prixAucune));
	}
	
	@DisplayName("Test AjouterPrix correctement")
	@Test
	void testAjouterPrix() throws PrixNonDisponibleException, DateDejaPresenteException {
		produit2.ajouterPrix(date, prixAucune);
		assertEquals(prixAucune , produit2.getPrix(date));
	}
	
	@DisplayName("Test AjouterPrix correctement et comparer reference")
	@Test
	void testAjouterPrixClone() throws PrixNonDisponibleException, DateDejaPresenteException {
		produit2.ajouterPrix(date, prixAucune);
		assertEquals(prixAucune , produit2.getPrix(date));
	}
	
	@DisplayName("test si attribut est bien clone de getPrix")
	@Test
	void testGetPrix() throws PrixNonDisponibleException {
		assertNotSame(produit1.getPrix(date), prixAucune);
	}

	@Test
	void testEqualsObject() {
		fail("Not yet implemented");
	}

	@Test
	void testClone() {
		fail("Not yet implemented");
	}

}
