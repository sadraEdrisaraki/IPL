<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8">
		<title>Un premier script PHP selon un modèle (m)vc</title>
	</head>
	<body>