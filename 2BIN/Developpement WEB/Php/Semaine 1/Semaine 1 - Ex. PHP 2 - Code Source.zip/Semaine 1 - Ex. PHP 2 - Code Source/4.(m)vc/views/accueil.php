		<p><?php echo $message ?></p>
		<p>Nous sommes le <?php echo $date ?>.</p>