<section id="contenu">
    <h2>La Genèse</h2>
    <p>Bienvenue sur la page de la genèse.</p>
    <p>Cette page est demandée grâce à la valeur 'genese' du paramètre 'action' passé par la méthode GET, visible dans
        l'URL /index.php?action=genese.</p>
    <table id="tableBalises">
        <thead>
        <tr>
            <th>Balise</th>
            <th>Signification</th>
            <th>Usage</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td><span class="html">table</span></td>
            <td>
            </td>
            <td>délimite la table</td>
        </tr>
        <tr>
            <td><span class="html">caption</span></td>
            <td>
            </td>
            <td>donne le titre (se place directement après la balise table)</td>
        </tr>
        <tr>
            <td><span class="html">tr</span></td>
            <td>table row</td>
            <td>d&eacute;limite une ligne</td>
        </tr>
        <tr>

            <td><span class="html">td</span></td>
            <td>table data</td>
            <td>d&eacute;limite une cellule de données</td>
        </tr>
        <tr>
            <td><span class="html">th</span></td>
            <td>table header</td>
            <td>donne une cellule d'en-t&ecirc;te de ligne ou colonne</td>
        </tr>
        </tbody>
    </table>
    <img src="<?php echo CHEMIN_VUES ?>images/big-w3cvalidtemplate.png" alt="W3C Valid">
</section>