<footer>
    <p id="copyright">Mise en page s'inspirant d'<a href="http://www.alsacreations.com/tutoriels/" target="_blank">Alsacréations</a>
    </p>
</footer>
</body>
</html>