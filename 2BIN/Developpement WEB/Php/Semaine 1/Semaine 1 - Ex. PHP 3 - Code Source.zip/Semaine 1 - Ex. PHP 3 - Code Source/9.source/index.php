<?php
# Définition des variables globales du script
define('CHEMIN_VUES', 'views/');

# Ecriture du header de toutes pages HTML
require_once(CHEMIN_VUES . 'header.php');

# S'il n'y a pas de variable GET 'action' dans l'URL, elle est créée ici à la valeur 'accueil'
if (empty($_GET['action'])) {
    $_GET['action'] = 'accueil';
}
# Switch case sur l'action demandée par la variable GET 'action' précisée dans l'URL
# index.php?action=...
switch ($_GET['action']) {
    case 'genese': # action=genese
        require_once('controllers/GeneseController.php');
        $controller = new GeneseController();
        break;
    default: # dans tous les autres cas l'action=accueil
        require_once('controllers/AccueilController.php');
        $controller = new AccueilController();
        break;
}
# Exécution du contrôleur défini dans le switch précédent
$controller->run();

# Ecrire ici le footer de toutes pages HTML
require_once(CHEMIN_VUES . 'footer.php');
?>