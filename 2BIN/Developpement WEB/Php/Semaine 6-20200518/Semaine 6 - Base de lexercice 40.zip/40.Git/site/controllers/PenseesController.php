<?php
class PenseesController{

    private $_db;

    public function __construct($db) {
        $this->_db = $db;
    }


    public function run(){
        # Y a-t-il des pensées ?
        $nbpensees = $this->_db->count_pensees();
        if ($nbpensees == 0) {
            $unepensee = NULL;
        } else {
            # Une pensée tirée au hasard dans la table des pensées
            $unepensee = $this->_db->select_random_pensee();
            # Mettre à jour la date et le nombre d'affichages d'une pensée
            date_default_timezone_set('Europe/Brussels');
            $datetime = date("Y-m-d H:i:s");
            $this->_db->update_pensee_affichee($unepensee->no(),$datetime);
        }

        # Est-ce que l'utilisateur veut voir toutes les pensées ?
        $tabpensees = NULL;
        if (!empty($_GET['see']) && $_GET['see']=='all') {
            $tabpensees = $this->_db->select_pensees();
        }

        # Ecrire ici une des vues
        if (!empty($tabpensees)) {
            require_once(CHEMIN_VUES . 'penseesall.php');
        } elseif (!empty($unepensee)) {
            require_once(CHEMIN_VUES . 'pensees.php');
        } else {
            require_once(CHEMIN_VUES . 'pasdepensee.php');
        }
    }

}
?>