<?php

class ContactController
{

    public function __construct()
    {

    }

    public function run()
    {
        # Envoi d'un email sur base des informations du formulaire transmises par la méthode POST
        $notification = '';
        if (!empty($_POST)) {
            if (empty($_POST['email']) && empty($_POST['message'])) {
                $notification = 'Veuillez entrer une adresse email et un message.';
            } elseif (empty($_POST['email'])) {
                $notification = 'Veuillez entrer une adresse email.';
            } elseif (empty($_POST['message'])) {
                $notification = 'Veuillez entrer un message.';
            } elseif (!preg_match('/^.+\@.+\..+$/', $_POST['email'])) {
                $notification = 'Veuillez entrer une adresse email correcte.';
            } else {
                require_once(CHEMIN_CONTROLEURS.'lib/PHPMailer-master/src/PHPMailer.php');
                require_once(CHEMIN_CONTROLEURS.'lib/PHPMailer-master/src/SMTP.php');
                require_once(CHEMIN_CONTROLEURS.'lib/PHPMailer-master/src/Exception.php');
                // Le namespace de PHPMailer est PHPMailer\PHPMailer;
                $mail = new PHPMailer\PHPMailer\PHPMailer(true);    // Passing `true` enables exceptions
                try {
                    // Server settings
                    $mail->SMTPDebug = 0;   // Disable verbose debug output (2 pour activer)
                    $mail->isSMTP();        // Set mailer to use SMTP
                    $mail->Host = 'in-v3.mailjet.com';  // Specify main SMTP server
                    $mail->SMTPAuth = true;             // Enable SMTP authentication
                    $mail->Username = '';  // SMTP username
                    $mail->Password = '';  // SMTP password
                    $mail->SMTPSecure = 'tls';          // Enable TLS encryption, 'ssl' also accepted
                    $mail->Port = 587;                  // TCP port to connect to

                    //Recipients
                    $mail->setFrom('...@student.vinci.be', 'My Mailjet Mailer');
                    $mail->addAddress('...@student.vinci.be', 'Votre nom'); // Add a recipient
                    $mail->addReplyTo(htmlspecialchars($_POST['email']), 'Poster');
                    //$mail->addCC('cc@example.com');
                    //$mail->addBCC('bcc@example.com');

                    //Attachments
                    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
                    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

                    //Content
                    $mail->isHTML(true);           // Set email format to HTML
                    $mail->Subject = 'Mail du site des bonnes nouvelles';
                    $mail->Body = htmlspecialchars($_POST['message']);

                    $mail->send();
                    $notification = 'Vos informations ont été transmises avec succès.';
                } catch (Exception $e) {
                    $notification = 'Vos informations n\'ont pas été transmises. ' . 'Mailer Error: ' . $mail->ErrorInfo;
                }
            }
        }

        # Ecrire ici la vue
        require_once(CHEMIN_VUES . 'contact.php');
    }
}

?>