<?php

class AdminController
{

    private $_db;

    public function __construct($db)
    {
        $this->_db = $db;
    }


    public function run()
    {
        # Si un petit fûté écrit ?action=admin sans passer par l'action login
        if (empty($_SESSION['authentifie'])) {
            header("Location: index.php?action=login"); # redirection HTTP vers l'action login
            die();
        }
        # Arrivé ici l'authentification est valide... continuons...

        # Variable HTML pour la vue
        $html_pseudo = htmlspecialchars($_SESSION['login']);
        $notification = '';
        $tablivres = '';

        $vueupdate = false; # La vue partielle de mise à jour n'est pas à afficher;

        # Gestion du tableau d'administration des livres
        if (!empty($_POST['form_enregistrer'])) {
            # ----------------------------------------
            # Un livre sélectionné est à mettre à jour
            # ----------------------------------------
            if (!empty($_POST['titre']) && !empty($_POST['auteur'])) {
                $this->_db->update_livre($_POST['nolivre'], $_POST['titre'], $_POST['auteur']);
                $notification = 'Le livre a bien été mis à jour';
            } else {
                $notification = 'Veuillez entrer un titre et un auteur';
                $livre = $this->_db->select_livre($_POST['nolivre']);
                $vueupdate = true;
            }
        } elseif (!empty($_POST['form_delete'])) {
            # ----------------------------------------------------------------------------------
            # Effacer un livre dont le numéro est l'indice dans le tableau $_POST['form_delete']
            # ----------------------------------------------------------------------------------
            # var_dump($_POST['form_delete'];
            foreach ($_POST['form_delete'] as $no => $action) {
                $this->_db->delete_livre($no);
            }
            $notification = 'Le livre ' . $no . ' a bien été effacé';
        } elseif (!empty($_POST['form_update'])) {
            # ---------------------------------------------------------------------------------------------
            # Un seul livre est à mettre à jour spécifié par l'indice dans le tableau $_POST['form_update']
            # ---------------------------------------------------------------------------------------------
            # Sélectionner les informations du livre correspondant
            # var_dump($_POST['form_update']);
            foreach ($_POST['form_update'] as $no => $action) {
                $livre = $this->_db->select_livre($no);
            }
            $vueupdate = true; # La vue partielle de mise à jour est à afficher;
        }

        # Gestion de l'ajout d'un utilisateur
        if (!empty($_POST['form_ajout'])) {
            if (!empty($_POST['pseudo']) && !empty($_POST['mdp'])) {
                if ($this->_db->pseudo_exists($_POST['pseudo'])) {
                    $notification = 'Le pseudo existe déjà, choisissez un autre pseudo';
                } elseif (empty($_FILES['photo']['tmp_name'])) {
                    $this->_db->insert_utilisateur($_POST['pseudo'], password_hash($_POST['mdp'], PASSWORD_BCRYPT));
                } else {
                    $imageinfo = getimagesize($_FILES['photo']['tmp_name']);
                    if (($_FILES['photo']['type'] == 'image/jpeg' && $imageinfo['mime'] == 'image/jpeg') || ($_FILES['photo']['type'] == 'image/png' && $imageinfo['mime'] == 'image/png')) {
                        $horodatage = str_replace('.', '_', microtime(true));
                        $origine = $_FILES['photo']['tmp_name'];
                        $destination = CHEMIN_VUES . 'images/' . $horodatage . basename($_FILES['photo']['name']);
                        move_uploaded_file($origine, $destination);
                        $this->_db->insert_utilisateur($_POST['pseudo'], password_hash($_POST['mdp'], PASSWORD_BCRYPT), $destination);
                        $notification = 'L\'utilisateur a bien été ajouté';
                    } else {
                        $notification = 'Le fichier uploadé doit être une image .jpg ou .png !';
                    }
                }

            } else {
                $notification = 'Veuillez entrer un pseudo et un mot de passe';
            }
        }

        # Changer le mot de passe ?
        if (!empty($_POST['form_chgmdp'])) {
            if (!$this->_db->valider_utilisateur($_SESSION['login'],$_POST['oldmdp'])) {
                $notification = 'Votre ancien mot de passe n\'est pas correct.';
            } elseif ($_POST['newmdp1'] != $_POST['newmdp2']) {
                $notification = 'Le nouveau mot de passe n\'est pas encodé deux fois correctement.';
            } else {
                # Modification du mot de passe dans la base de donnée, le pseudo est considéré comme unique
                $this->_db->update_mdp($_SESSION['login'],password_hash($_POST['newmdp1'], PASSWORD_BCRYPT));
                $notification = 'Votre mot de passe a bien été changé.';
            }
        }

        # Gestion de l'import d'un fichier .csv
        # ...

        # Gestion de l'export d'un fichier .csv
        # ...

        # Sélection de tous les livres à afficher
        $tablivres = $this->_db->select_livres();

        # Sélection de tous les utilisateurs à afficher
        $tabutilisateurs = $this->_db->select_utilisateurs();

        # Ecrire ici la vue
        require_once(CHEMIN_VUES . 'admin.php');
        if ($vueupdate) {
            require_once(CHEMIN_VUES . 'admin.update.php');
        }
    }
}

?>