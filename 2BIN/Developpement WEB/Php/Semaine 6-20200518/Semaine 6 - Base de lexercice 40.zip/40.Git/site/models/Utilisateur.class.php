<?php
class Utilisateur{
	private $_no;
	private $_pseudo;
	private $_mdp;
	private $_photo;
	
	public function __construct($no,$pseudo,$mdp,$photo){
		$this->_no = $no;
		$this->_pseudo = $pseudo;
		$this->_mdp = $mdp;
		$this->_photo = $photo;
	}
	
	public function no(){
		return $this->_no;		
	}	
		
	public function pseudo(){
		return $this->_pseudo;
	}
	
	public function mdp(){
		return $this->_mdp;
	}
	
	public function photo(){
		return $this->_photo;
	}
	
	public function html_no(){
		return htmlspecialchars($this->_no);	
	}	
		
	public function html_pseudo(){
		return htmlspecialchars($this->_pseudo);
	}
	
	public function html_mdp(){
		return htmlspecialchars($this->_mdp);
	}
	
	public function html_photo(){
		return htmlspecialchars($this->_photo);
	}
}
?>