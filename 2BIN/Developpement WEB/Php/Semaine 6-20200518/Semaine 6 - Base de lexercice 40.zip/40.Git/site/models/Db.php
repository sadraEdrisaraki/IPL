<?php
class Db
{
    private static $instance = null;
    private $_db;

    private function __construct()
    {
        try {
            $this->_db = new PDO('mysql:host=localhost;dbname=bdbn;charset=utf8', 'root', '');
            $this->_db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
			$this->_db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_OBJ);
        } 
		catch (PDOException $e) {
		    die('Erreur de connexion à la base de données : '.$e->getMessage());
        }
    }

	# Pattern Singleton
    public static function getInstance()
    {
        if (is_null(self::$instance)) {
            self::$instance = new Db();
        }
        return self::$instance;
    }

    # Fonction qui exécute un SELECT dans la table des livres
    # et qui renvoie un tableau d'objet(s) de la classe Livre
    public function select_livres($keyword='') {
        # Définition du query et préparation
        if ($keyword != '') {
            $keyword = str_replace("%", "\%", $keyword);
            $query = "SELECT * FROM livres WHERE titre LIKE :keyword COLLATE utf8_bin ORDER BY no DESC ";
            $ps = $this->_db->prepare($query);
            # Le bindValue se charge de quoter proprement les valeurs des variables sql
            $ps->bindValue(':keyword',"%$keyword%");
        } else {
            $query = 'SELECT * FROM livres ORDER BY no DESC';
            $ps = $this->_db->prepare($query);
        }

        # Exécution du prepared statement
        $ps->execute();

        $tableau = array();
        # Parcours de l'ensemble des résultats
        # Construction d'un tableau d'objet(s) de la classe Livre
        # Si le tableau est vide, on ne rentre pas dans le while
        while ($row = $ps->fetch()) {
            $tableau[] = new Livre($row->no,$row->titre,$row->auteur);
        }
        # Pour debug : affichage du tableau à renvoyer
        # var_dump($tableau);
        return $tableau;
    }

    public function insert_livre($titre,$auteur) {
        # Solution d'INSERT avec prepared statement
        $query = 'INSERT INTO livres (titre, auteur) values (:titre,:auteur)';
        $ps = $this->_db->prepare($query);
        $ps->bindValue(':titre',$titre);
        $ps->bindValue(':auteur',$auteur);
        return $ps->execute();
    }

    public function delete_livre($no) {
        # Solution de DELETE avec prepared statement
        $query = 'DELETE FROM livres WHERE no=:no LIMIT 1';
        $ps = $this->_db->prepare($query);
        $ps->bindValue(':no',$no);
        return $ps->execute();
    }

    public function select_livre($no) {
        $query = 'SELECT * FROM livres WHERE no=:no';
        $ps = $this->_db->prepare($query);
        $ps->bindValue(':no',$no);
        $ps->execute();
        $row = $ps->fetch();
        return new Livre($row->no,$row->titre,$row->auteur);
    }

    public function update_livre($no,$titre,$auteur) {
        $query = 'UPDATE livres SET titre=:titre,auteur=:auteur WHERE no=:no';
        $ps = $this->_db->prepare($query);
        $ps->bindValue(':titre',$titre);
        $ps->bindValue(':auteur',$auteur);
        $ps->bindValue(':no',$no);
        return $ps->execute();
    }

    public function select_utilisateurs() {
        $query = 'SELECT * FROM utilisateurs ORDER BY no ASC';
        $ps = $this->_db->prepare($query);
        $ps->execute();
        $tableau = array();
        while ($row = $ps->fetch()) {
            $tableau[] = new Utilisateur($row->no,$row->pseudo,$row->mdp,$row->photo);
        }
        # var_dump($tableau);
        return $tableau;
    }

    public function insert_utilisateur($pseudo,$mdp,$photo=NULL) {
        $query = 'INSERT INTO utilisateurs (pseudo,mdp,photo) values (:pseudo,:mdp,:photo)';
        $ps = $this->_db->prepare($query);
        $ps->bindValue(':pseudo',$pseudo);
        $ps->bindValue(':mdp',$mdp);
        $ps->bindValue(':photo',$photo);
        return $ps->execute();
    }

    public function valider_utilisateur($pseudo,$mdp) {
        $query = 'SELECT mdp from utilisateurs WHERE pseudo=:pseudo';
        $ps = $this->_db->prepare($query);
        $ps->bindValue(':pseudo',$pseudo);
        $ps->execute();
        if ($ps->rowcount() == 0)
            return false;
        $hash = $ps->fetch()->mdp;
        return password_verify($mdp, $hash);
    }

    public function pseudo_exists($pseudo) {
        $query = 'SELECT * from utilisateurs WHERE pseudo=:pseudo';
        $ps = $this->_db->prepare($query);
        $ps->bindValue(':pseudo',$pseudo);
        $ps->execute();
        return ($ps->rowcount() != 0);
    }

    public function update_mdp($pseudo,$mdp) {
        $query = 'UPDATE utilisateurs SET mdp=:mdp WHERE pseudo=:pseudo';
        $ps = $this->_db->prepare($query);
        $ps->bindValue(':pseudo',$pseudo);
        $ps->bindValue(':mdp',$mdp);
        return $ps->execute();
    }

    public function count_pensees() {
        $query = 'SELECT count(*) as nbpensees FROM pensees';
        $ps = $this->_db->prepare($query);
        $ps->execute();
        $row = $ps->fetch();
        return $row->nbpensees;
    }

    public function select_random_pensee() {
        $query = 'SELECT * FROM pensees ORDER BY RAND() LIMIT 1';
        $ps = $this->_db->prepare($query);
        $ps->execute();
        $row = $ps->fetch();
        return new Pensee($row->no,$row->pensee,$row->auteur,$row->dateaffichage,$row->nbaffichage);
    }

    public function update_pensee_affichee($no,$datetime) {
        $query = 'UPDATE pensees SET nbaffichage=nbaffichage+1,dateaffichage=:dateaffichage WHERE no=:no';
        $ps = $this->_db->prepare($query);
        $ps->bindValue(':dateaffichage',$datetime);
        $ps->bindValue(':no',$no);
        return $ps->execute();
    }
}