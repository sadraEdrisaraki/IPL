<?php
class Pensee{
    private $_no;
    private $_pensee;
    private $_auteur;
    private $_dateaffichage;
    private $_nbaffichage;

    public function __construct($no,$pensee,$auteur,$dateaffichage,$nbaffichage){
        $this->_no = $no;
        $this->_pensee = $pensee;
        $this->_auteur = $auteur;
        $this->_dateaffichage = $dateaffichage;
        $this->_nbaffichage = $nbaffichage;
    }

    public function no(){
        return $this->_no;
    }

    public function pensee(){
        return $this->_pensee;
    }

    public function auteur(){
        return $this->_auteur;
    }

    public function dateaffichage(){
        return $this->_dateaffichage;
    }

    public function nbaffichage(){
        return $this->_nbaffichage;
    }

    public function html_no(){
        return htmlspecialchars($this->_no);
    }

    public function html_pensee(){
        return htmlspecialchars($this->_pensee);
    }

    public function html_auteur(){
        return htmlspecialchars(substr($this->_auteur,1,-1));
    }

    public function html_dateaffichage(){
        return htmlspecialchars($this->_dateaffichage);
    }

    public function html_nbaffichage(){
        return htmlspecialchars($this->_nbaffichage);
    }
}
?>