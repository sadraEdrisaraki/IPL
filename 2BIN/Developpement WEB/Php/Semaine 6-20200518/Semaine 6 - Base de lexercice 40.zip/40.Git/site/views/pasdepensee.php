<section class="contenu">
    <h2>Pensées</h2>
    <p>Bienvenue sur la page des pensées.</p>
    <p>Cette page est demandée grâce à la valeur 'pensees' du paramètre 'action' passé par la méthode GET, visible dans
        l'URL /index.php?action=pensees.</p>
    <p>Pas de pensées pour l'instant.</p>
</section>
