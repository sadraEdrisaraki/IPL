<section div class="contenu">
    <h2>Login vers la zone d'administration</h2>
    <p>Bienvenue sur la page de login.</p>
    <p>Cette page est demandée grâce à la valeur 'login' du paramètre 'action' passé par la méthode GET, visible dans
        l'URL /index.php?action=login.</p>
    <div id="notification"><?php echo $notification; ?></div>
    <div class="formulaire">
        <form action="?action=login" method="post">
            <p>Login : <input type="text" name="nomdutilisateur" /></p>
            <p>Mot de passe : <input type="password" name="motdepasse" /></p>
            <p><input type="submit" name="form_login" value="Se connecter"></p>
        </form>
    </div>
</section>
