<section class="contenu">
    <h2>Pensées</h2>
    <p>Bienvenue sur la page des pensées.</p>
    <p>Cette page est demandée grâce à la valeur 'pensees' du paramètre 'action' passé par la méthode GET, visible dans
        l'URL /index.php?action=pensees.</p>
    <p>No : <?php echo $unepensee->html_no() ?><br/>
        Pensée : <?php echo $unepensee->html_pensee() ?><br/>
        Auteur : <?php echo $unepensee->html_auteur() ?><br/>
    </p>
    <p><a href='index.php?action=pensees&amp;see=all'>Voir toutes les pensées</a>
        <a href='index.php?action=pensees'>Masquer toutes les pensées</a></p>
    <table id="tableBalises">
        <thead>
        <tr>
            <th>Numéro</th>
            <th>Pensée</th>
            <th>Auteur</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($tabpensees as $i => $pensee) { ?>
            <tr>
                <td><span class="html"><?php echo $pensee->html_no() ?></span></td>
                <td><?php echo $pensee->html_pensee() ?></td>
                <td><?php echo $pensee->html_auteur() ?></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</section>
