<div class="contenu">
    <form action="?action=admin" method="post">
        <table id="tableBalises">
            <thead>
            <tr>
                <th>Titre</th>
                <th>Auteur</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td><input type="text" name="titre" value="<?php echo $livre->html_titre() ?>" size="50"></td>
                <td><input type="text" name="auteur" value="<?php echo $livre->html_auteur() ?>"></td>
                <td><input type="submit" name="form_enregistrer" value="Enregistrer">
                    <input type="hidden" name="nolivre" value="<?php echo $livre->html_no() ?>"></td>
            </tr>
            </tbody>
        </table>
    </form>
</div><!-- #contenu -->