<section class="contenu">
    <h2>Zone d'Administration</h2>
    <p>Bienvenue <?php echo $html_pseudo; ?></p>
    <p><a href="index.php?action=logout">Se déconnecter</a></p>
    <div id="notification"><?php echo $notification; ?></div>
    <form action="?action=admin" method="post">
        <table id="tableBalises">
            <thead>
            <tr>
                <th>Titre</th>
                <th>Auteur</th>
                <th></th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php for ($i = 0; $i < count($tablivres); $i++) { ?>
                <tr>
                    <td><span class="html"><?php echo $tablivres[$i]->html_titre() ?></span></td>
                    <td><?php echo $tablivres[$i]->html_auteur() ?></td>
                    <td><input type="submit" name="form_delete[<?php echo $tablivres[$i]->html_no() ?>]" value="Effacer"></td>
                    <td><input type="submit" name="form_update[<?php echo $tablivres[$i]->html_no() ?>]" value="Mettre à jour"></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </form>
    <table id="tableBalises">
        <thead>
        <tr>
            <th>Pseudo</th>
            <th>Photo</th>
        </tr>
        </thead>
        <tbody>
        <?php for ($i=0;$i<count($tabutilisateurs);$i++) { ?>
            <tr>
                <td><span class="html"><?php echo $tabutilisateurs[$i]->pseudo() ?></span></td>
                <?php if (is_null($tabutilisateurs[$i]->photo())||!file_exists($tabutilisateurs[$i]->photo())) { ?>
                    <td><img class="photo" src="<?php echo CHEMIN_VUES ?>images/imgenerique.jpg" alt="image générique" /></td>
                <?php } else { ?>
                    <td><img class="photo" src="<?php echo $tabutilisateurs[$i]->photo() ?>" alt="<?php echo $tabutilisateurs[$i]->pseudo() ?>" /></td>
                <?php } ?>
            </tr>
        <?php } ?>
        </tbody>
    </table>
    <div class="formulaire">
        <form enctype="multipart/form-data" action="index.php?action=admin" method="post">
            <p>Ajouter un nouvel utilisateur</p>
            <p>Pseudo :	<input type="text" name="pseudo" /></p>
            <p>Mot de passe : <input type="password" name="mdp" /></p>
            <p>Photo : <input type="hidden" name="MAX_FILE_SIZE" value="1000000" />
                <input type="file" name="photo" /></p>
            <p><input type="submit" name="form_ajout" value="Ajouter"></p>
        </form>
    </div>
    <div class="formulaire">
        <form action="index.php?action=admin" method="post">
            <p>Changer votre mot de passe</p>
            <p>Ancien mot de passe : <input type="password" name="oldmdp" /></p>
            <p>Nouveau mot de passe : <input type="password" name="newmdp1" /></p>
            <p>Répéter le nouveau mot de passe : <input type="password" name="newmdp2" /></p>
            <p><input type="submit" name="form_chgmdp" value="Changer"></p>
        </form>
    </div>
    <div class="formulaire">
        <form enctype="multipart/form-data" action="index.php?action=admin" method="post">
            <p>Importer un fichier de pensées .csv</p>
            <p>Fichier .csv : <input type="hidden" name="MAX_FILE_SIZE" value="10000000" />
                <input type="file" name="csvfile" /></p>
            <p><input type="submit" name="form_import_csv" value="Importer"></p>
        </form>
    </div>
    <div class="formulaire">
    <form action="index.php?action=admin" method="post">
        Exporter un fichier de pensées .csv
        <input type="submit" name="form_export_csv" value="Exporter">
    </form>
    </div>
</section>
