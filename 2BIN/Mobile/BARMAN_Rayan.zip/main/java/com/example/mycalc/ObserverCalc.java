package com.example.mycalc;

public interface ObserverCalc {

    public abstract void makeChangebyNotify();

}
