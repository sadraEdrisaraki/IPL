Lien vers les différentes vidéos:
	Construire un modèle isolant la logique business : https://www.loom.com/share/f8c2433f8b4e46e3a4f4b8797d5bc7ef
	Implémenter un diagramme d'état de façon propre : https://www.loom.com/share/d53348417acd40aaa6645e16c9a0fd54
	Utiliser le débugger : https://www.loom.com/share/60e75029583947c4a2f38ab96b5fdfc6
	Utiliser les logs : https://www.loom.com/share/f847a7e992304f4da5190247554a3bf8
	
