public class Inscription {
	private Ecole[] ecoles;
	//vous pouvez rajouter des attributs
	
	//� compl�ter: initialisation des attributs
	public Inscription(Ecole... ecoles){
		this.ecoles=ecoles;
	}
	
	// enregistre la demande d'inscription d'un �l�ve � une �cole.
	// Lance une RunTimeException si l'�l�ve a d�j� fait 3 demandes d'inscription
	// Complexit�: ? 
	public void demandeInscription(Eleve eleve,Ecole ecole){
	}
	
	// parcourt les demandes d'inscription des �l�ves et inscrit les �l�ves selon
	// l'ordre premier arriv� premier servi. Pour inscrire un �l�ve,
	// il faut appeler la m�thode ajouterEleve de la classe Ecole. 
	// Les �l�ves d�j� inscrits dans une autre �cole ne sont pas inscrits.
	// Complexit�: ?
	public void remplirEcole(Ecole ecole) {
	}
}
