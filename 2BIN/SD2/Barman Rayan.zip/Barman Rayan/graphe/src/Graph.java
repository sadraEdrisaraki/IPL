import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

public class Graph {

	private LinkedList<Troncon> troncons;

	//lit le fichier et remplit la structure de donn�es troncons
	public Graph(String xmlFile) throws Exception {
	}
	
	public void bfs(String depart, String arrivee) {
		Set<String> visited = new HashSet<String>();
		Queue<String> queue = new LinkedList<String>();
		queue.add(depart);
		visited.add(depart);
		while (!queue.isEmpty()) {
			String cur = queue.poll();
			System.out.print(cur + " ");
			for (Troncon t : troncons) {
				if (t.getDepart().equals(cur) && !visited.contains(t.getArrivee())) {
					queue.add(t.getArrivee());
					visited.add(t.getArrivee());
				}
			}
		}
	}

	public static void main(String[] args) throws Exception {
		Graph g = new Graph("stib.xml");
		g.bfs("MALIBRAN", "ALMA");
	}
}