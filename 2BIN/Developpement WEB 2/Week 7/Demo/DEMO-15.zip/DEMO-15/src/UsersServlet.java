import java.util.Collection;
import java.util.List;
import java.io.IOException;
//import java.nio.file.Files;
//import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.owlike.genson.GenericType;
import com.owlike.genson.Genson;

@SuppressWarnings("serial")
public class UsersServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{ 
		//super.doGet(req, resp);
		try {
			System.out.println("USERS GET CALL");			
			// the users DB is a json file
			// read the file
			// get the content of the file to be sent back to the client
			String json = new String(Files.readAllBytes(Paths.get("./data/users.json")));
			
			// get the JSON object from the string (content of the file): deserialized to a list of map
			Genson genson = new Genson();
			List<User> users = genson.deserialize(json, new GenericType<List<User>>(){});
			
			String table = new String();
			table = "<p><h3>List of users :</h3></p> <br><table><tr><th>Fullname</th><th>Email</th>";
			// create html table from List<User>
			for (User element : users) {
			    //System.out.println(element);
			    //System.out.println((String) element.fullname);  
				table+="<tr><td>" + element.fullname +"</td>";
				table+="<td>" + element.email +"</td><tr>";
			}
			table+="</table>";			
			// prepare the response to be sent back to the user
			resp.setContentType("text/html");		
			resp.setCharacterEncoding("utf-8");			
	        resp.setStatus(HttpServletResponse.SC_OK); 
	        resp.getWriter().write(table);			
			}
		
		catch(Exception e) {
			e.printStackTrace();
			resp.setStatus(500); 
			resp.setContentType("text/html");
			byte[] msgBytes=e.getMessage().getBytes("UTF-8");
			resp.setContentLength(msgBytes.length);
			resp.setCharacterEncoding("utf-8");
			resp.getOutputStream().write(msgBytes);
			}
		}
	}

class User {
	  public String email;
	  public String fullname ;
	  // there shall be a constructor with no parameters to set the collection !
	  public User() {};	  
	  public User(String fullname, String email){
		  this.email = email;
		  this.fullname = fullname;
	  }	  
	}
