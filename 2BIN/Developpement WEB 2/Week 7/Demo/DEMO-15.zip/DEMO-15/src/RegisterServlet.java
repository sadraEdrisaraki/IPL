import java.io.IOException;
//import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
//import java.util.Random;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.owlike.genson.GenericType;
import com.owlike.genson.Genson;

@SuppressWarnings("serial")
public class RegisterServlet extends HttpServlet {
	// A) this GET method shall provide the content of the connect.html file when requested by the user
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{ 
		//super.doGet(req, resp);
		try {		
			resp.setContentType("text/html");		
			resp.setCharacterEncoding("utf-8");
			// get the content of the file to be sent back to the client
			String body = new String(Files.readAllBytes(Paths.get("./views/users.html")));	
	        resp.setStatus(HttpServletResponse.SC_OK); 
	        resp.getWriter().write(body);							
			}
		
		catch(Exception e) {
			e.printStackTrace();
			resp.setStatus(500); 
			resp.setContentType("text/html");
			byte[] msgBytes=e.getMessage().getBytes("UTF-8");
			resp.setContentLength(msgBytes.length);
			resp.setCharacterEncoding("utf-8");
			resp.getOutputStream().write(msgBytes);
			}
		}
	
	// this POST method shall provide a personal message by redirecting to /welcome
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			System.out.println("REGISTER POST CALL");
			
			// get the parameters sent by the POST form
			String email = req.getParameter("email");
			String fullname = req.getParameter("fullname");
			
			// read the file
			// get the content of the file
			String json = new String(Files.readAllBytes(Paths.get("./data/users.json")));
			// get the JSON object from the string (content of the file): deserialized to a list of map
			Genson genson = new Genson();
			List<User> users = genson.deserialize(json, new GenericType<List<User>>(){});
			
			users.add(new User(fullname,email));			
			//rewrite the ./data/users.json file from the List
			// 1. serialize the collection
			json = genson.serialize(users);
			System.out.println(json);
			// write the file (even if it exists)
			Files.write(Paths.get("./data/users.json"), json.getBytes());			
			// redirect to the URL that shows all registered users
			resp.sendRedirect("/users");		
			}
		
		catch(Exception e) {
			e.printStackTrace();
			resp.setStatus(500); 
			resp.setContentType("text/html");
			byte[] msgBytes=e.getMessage().getBytes("UTF-8");
			resp.setContentLength(msgBytes.length);
			resp.setCharacterEncoding("utf-8");
			resp.getOutputStream().write(msgBytes);
			}
	}
	
	}

	

