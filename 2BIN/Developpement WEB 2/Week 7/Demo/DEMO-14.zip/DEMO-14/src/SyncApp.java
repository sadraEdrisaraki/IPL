
import javax.servlet.http.HttpServlet;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.DefaultServlet;
import org.eclipse.jetty.servlet.ServletHolder;
import org.eclipse.jetty.webapp.WebAppContext;

public class SyncApp {

	public static void main(String[] args) throws Exception {
		// server to listen on specific port 8080
		Server server = new Server(8080); 
		// create the object to configure the web application
		WebAppContext context = new WebAppContext(); 
		
		System.out.println(context.getContextPath());
		context.setContextPath("/") ;
		
		// create a servlet to control the response to requests at a specific endpoint URL
		HttpServlet loginServlet =new LoginServlet();
		// set the router by providing, for a specifc URL endpoint, the required servlet 
		// as this is the first "router", this one takes priority over future ones
		context.addServlet(new ServletHolder(loginServlet), "/login");
		
		HttpServlet publicLoginServlet =new HomeServlet();
		// set the router by providing, for a specifc URL endpoint, the required servlet 
		context.addServlet(new ServletHolder(publicLoginServlet), "/home/*");
		
		// handling static content : create the shared folder of your website by using the DefaultServlet at ./public
		// futhermore, if the base URL is given, if it finds some welcome files (e.g. index.html), it publishes it, 
		// else it provides directory listings
		context.setResourceBase("public"); 
		// DefaultServlet : handling for static content = publish all your files in a smart way 
		HttpServlet statiContentServlet =new DefaultServlet(); // 
		// set the router by providing the root of the project "/"
		// statiContentServlet will publish files for all request, unless there is a request on 
		// /hello/* URL endpoint
		context.addServlet(new ServletHolder(statiContentServlet), "/");
		//context.
		//context.setAllowNullPathInfo(true);
		
	
		// provide the configuration object to the server
		server.setHandler(context); 
		server.start(); // d�marrage


	}

}