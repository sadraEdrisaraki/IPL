import java.io.IOException;
//import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
//import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class LoginServlet extends HttpServlet {
	// A) this GET method shall provide the content of the connect.html file when requested by the user
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{ 
		//super.doGet(req, resp);
		try {
			System.out.println("CONNECT GET CALL : " + req.getRequestURL());
			resp.setContentType("text/html");		
			resp.setCharacterEncoding("utf-8");
			// get the content of the file to be sent back to the client
			String body = new String(Files.readAllBytes(Paths.get("./views/login.html")));
			
	        resp.setStatus(HttpServletResponse.SC_OK); 
	        resp.getWriter().write(body);
			}
		
		catch(Exception e) {
			e.printStackTrace();
			resp.setStatus(500); 
			resp.setContentType("text/html");
			byte[] msgBytes=e.getMessage().getBytes("UTF-8");
			resp.setContentLength(msgBytes.length);
			resp.setCharacterEncoding("utf-8");
			resp.getOutputStream().write(msgBytes);
			}
		}
	
	// this POST method shall provide a personal message by redirecting to /welcome
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			System.out.println("CONNEC POST CALL");
			// get the parameters sent by the POST form
			String email = req.getParameter("email");
			String password = req.getParameter("password");		
			resp.setContentType("text/html");		
			resp.setCharacterEncoding("utf-8");
	        resp.setStatus(HttpServletResponse.SC_OK); 
	        resp.getWriter().write("<p><h3>Your e-mail :" + email +".<h3></p><p> We guessed your password Today : "+ password +" : )</p>");
			}
		
		catch(Exception e) {
			e.printStackTrace();
			resp.setStatus(500); 
			resp.setContentType("text/html");
			byte[] msgBytes=e.getMessage().getBytes("UTF-8");
			resp.setContentLength(msgBytes.length);
			resp.setCharacterEncoding("utf-8");
			resp.getOutputStream().write(msgBytes);
			}
	}
	
	}

	

