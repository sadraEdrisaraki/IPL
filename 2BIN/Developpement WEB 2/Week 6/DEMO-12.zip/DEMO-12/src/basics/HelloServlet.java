package basics;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class HelloServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//// TODO Auto-generated method stub
		//super.doGet(req, resp);
		resp.setContentType("text/html");
		//get the default character encoding
		System.out.println("Default character encoding:" + resp.getCharacterEncoding());
		resp.setCharacterEncoding("utf-8");
        resp.setStatus(HttpServletResponse.SC_OK); 
        resp.getWriter().println("<h1>Hello from HelloServlet!</h1>");
	}
	

}
