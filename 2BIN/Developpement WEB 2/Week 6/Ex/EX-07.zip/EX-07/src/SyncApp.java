
import javax.servlet.http.HttpServlet;

import org.eclipse.jetty.rewrite.handler.RedirectPatternRule;
import org.eclipse.jetty.rewrite.handler.RewriteHandler;
import org.eclipse.jetty.rewrite.handler.RewritePatternRule;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.DefaultServlet;
import org.eclipse.jetty.servlet.ServletHolder;
import org.eclipse.jetty.webapp.WebAppContext;

public class SyncApp {

	public static void main(String[] args) throws Exception {
		// server to listen on specific port 8080
		Server server = new Server(80); 
		// create the object to configure the web application
		WebAppContext context = new WebAppContext(); 
		
		System.out.println(context.getContextPath());
		context.setContextPath("/") ;
		
		// create a servlet to control the response to requests at a specific endpoint URL
		HttpServlet loginServlet =new LoginServlet();
		// A) set the router by providing, for a specifc URL endpoint, the required servlet 
		// as this is the first "router", this one takes priority over future ones
		context.addServlet(new ServletHolder(loginServlet), "/signin");
		
		HttpServlet rootServlet =new RootServlet();
		// B) set the router by providing, for a specifc URL endpoint, the required servlet 
		context.addServlet(new ServletHolder(rootServlet), "/");
		
		// handling static content : create the shared folder of your website at ./public
		context.setResourceBase("public"); 
	
		server.setHandler(context); 
		
		server.start(); // start


	}

}