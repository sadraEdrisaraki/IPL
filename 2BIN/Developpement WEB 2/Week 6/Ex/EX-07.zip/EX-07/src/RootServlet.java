import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
//import java.nio.file.Files;
//import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class RootServlet extends HttpServlet {
	// B) this GET method shall redirect to the public login.html file when requested by the user
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{ 
		//super.doGet(req, resp);
		try {
			System.out.println("ROOT GET CALL");
			System.out.println("Path:" + req.getRequestURI());
			//redirect if the base directory is given
			if(req.getRequestURI().contentEquals("/"))
				resp.sendRedirect("/signin");
			//else return the required file (there is a based folder named "public"
			else
				{
				
				try {
					String fileContent = Files.readString(Paths.get( "public" + req.getRequestURI()),  StandardCharsets.UTF_8);
					resp.setStatus(HttpServletResponse.SC_OK); 
			        resp.getWriter().write(fileContent);
				}
				catch(IOException e){
					resp.getWriter().write("This ressource does not exist");
				}
			
				}
			}
		
		catch(Exception e) {
			e.printStackTrace();
			resp.setStatus(500); 
			resp.setContentType("text/html");
			byte[] msgBytes=e.getMessage().getBytes("UTF-8");
			resp.setContentLength(msgBytes.length);
			resp.setCharacterEncoding("utf-8");
			resp.getOutputStream().write(msgBytes);
			}
		}
	}

