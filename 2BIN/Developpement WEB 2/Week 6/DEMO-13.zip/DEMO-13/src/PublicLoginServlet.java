import java.io.IOException;
//import java.nio.file.Files;
//import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class PublicLoginServlet extends HttpServlet {
	// B) this GET method shall redirect to the public login.html file when requested by the user
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{ 
		//super.doGet(req, resp);
		try {
			System.out.println("LOGIN GET CALL");
			resp.sendRedirect("/login.html");
			}
		
		catch(Exception e) {
			e.printStackTrace();
			resp.setStatus(500); 
			resp.setContentType("text/html");
			byte[] msgBytes=e.getMessage().getBytes("UTF-8");
			resp.setContentLength(msgBytes.length);
			resp.setCharacterEncoding("utf-8");
			resp.getOutputStream().write(msgBytes);
			}
		}
	}

	// this POST method shall provide a personal message by redirecting to /welcome
