$(document).ready(function () {
    //per default, hide the alertbox
    if($("#message_board").text()=="")
        $("#message_board").hide();
    else
        $("#message_board").show();
});