"use strict";
$(document).ready(function () {

    // call our API to get a list of users and refresh it every second
    setInterval(getUsersAndPrint, 1000);
    //getUsersAndPrint();

    //Attach a click handler
    $("#btn").click(function (e) { 
        // this prevent the form to be sent to the API
        e.preventDefault();
        // if the form is valid, POST the form data to the /users API          

        if ( $("#email").get(0).checkValidity() && $("#fullname").get(0).checkValidity() ) {
            $.ajax({
                type: "post",
                url: "/users",
                data: {email:$("#email").val(),fullname:$("#fullname").val()},
                dataType: "json",
                success: function (response) {
                    // success, therefore clear the form
                    $("#email").val("");
                    $("#fullname").val("");
                    console.log("success, form data was sent and processed by the API.");
                    // refresh the list of users by calling the GET / users API
                    getUsersAndPrint();

                },
                error: function name(err, status, message) {
                    console.log("Error :",status,"messsage:", message);
                }
            });   
        } 



    });


});


function getUsersAndPrint()
{
    //call the GET /users API to get all the registered users
    $.ajax({
        type: "get",
        url: "/users",
        // the mime type is well indicated in the API message, therefore dataType is not required
        // if json, JQuery convert the string to an object !
        dataType: "json",
        success: function (response) {
            // The response is directly a JSON object !
            // No need to parse the string (deserialization)
            //let resp_json = JSON.parse(response);
            let resp_json = response;
            if (resp_json.success) {
                //$("#message_board").text(JSON.stringify(response.data)
                //clean the div
                $("#message_board").text("");

                //write some dynamic html content within the div
                let list = document.createElement("ul");
                let users_array = response.data ;
                list.className="list-group";
                for (let i = 0; i < users_array.length; i++) {
                    //html_text += "<li>" + libraries[i] + "</li>";
                    // to demonstrate the use of bootstrap and the List group
                    var item = document.createElement("li");
                    item.className = "list-group-item";
                    item.innerText = users_array[i].fullname + " (" + users_array[i].email +")" ;
                    list.appendChild(item);
                }
                $("#message_board").append(list); 
            }
            else
            {
                $("#message_board").text(JSON.stringify(response.error)) ;  
            }
              
        }
    });
}