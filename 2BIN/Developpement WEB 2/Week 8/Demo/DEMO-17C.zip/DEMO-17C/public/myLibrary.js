"use strict";

async function postData(url = '', data = {},token) {
  try{
  console.log("data:",data);
  const response = await fetch(url, {
    method: 'POST', // GET, POST, PUT, DELETE, etc.
    body: JSON.stringify(data), // body data type must match "Content-Type" header
    headers: {
      'Content-Type': 'application/json',
      ...(token && {'Authorization': 'Bearer ' + token}),
    }
  });
  return await response.json();
}
catch(err){
  console.error("postData: err:",err);
}
   // parses JSON response into native JavaScript objects
}
async function getData(url = '',token) {
  // Default options are marked with *
  const response = await fetch(url, {
    method: 'get', // *GET, POST, PUT, DELETE, etc.
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      ...(token && {'Authorization': 'Bearer ' + token}),
    }
  });
  return await response.json(); // parses JSON response into native JavaScript objects
}



$(document).ready(function() {
  //per default, hide the login component, unless there is a token in localstorage
  let token = localStorage.getItem("token");
  if (token) {
    $("#login_component").hide();
    $("#register_component").show();
    $("#view_users_component").show();
    $("#logout_btn").show();
    // call our API to get a list of users and refresh it every 3 seconds
    setInterval(getUsersAndPrint, 3000);
    
  } else {
    $("#login_component").show();
    //per default, hide the message board (to deal with error)
    if ($("#login_board").text() == "") $("#login_board").hide();
    //per default, hide the other components
    $("#register_component").hide();
    $("#view_users_component").hide();
    $("#logout_btn").hide();
  }

  $("#login_form").submit(e => {
    e.preventDefault();
    //
    console.log("within login submit");
    if ($("#email1")[0].checkValidity() && $("#password1")[0].checkValidity()) {
      const data={ email: $("#email1").val(), password: $("#password1").val() };
      postData("/login",data) 
      .then(response => {
        // success, therefore make the form disappear
        $("#email1").val("");
        $("#password1").val("");
        console.log("response:",response);
        if (response.success === "true") {
          console.log("Token:", response);
          // store the jwt in localstorage
          localStorage.setItem("token", response.token);
          token = response.token;        

          //hide login component and show other components
          $("#login_board").html("");
          $("#login_component").hide();
          $("#register_component").show();
          $("#view_users_component").show();
          $("#logout_btn").show();

          // call our API to get a list of users and refresh it every 3 seconds
          setInterval(getUsersAndPrint, 3000);

        } else {
          //show error message
          console.log("Error:", response);
          $("#login_board").html(response.error);
          $("#login_board").show();
        }
      })
      .catch(err =>{
        console.error("Error :", err);
          $("#login_board").html(message);
          $("#login_board").show();
      });
      
    } else {
      alert("Please provide valid credentials.");
    }
  });
  
  //Attach a click handler to the register form
  $("#btn").click(function(e) {
    // this prevent the form to be sent to the API
    e.preventDefault();
    // if the form is valid, POST the form data to the /users API

    if (
      $("#email")
        .get(0)
        .checkValidity() &&
      $("#fullname")
        .get(0)
        .checkValidity()
    ) {
      const data={ email: $("#email").val(), fullname: $("#fullname").val() };
      postData("/users",data,token) 
      .then(response => {
        // success, therefore clear the form
        $("#email").val("");
        $("#fullname").val("");
        console.log("success, form data was sent and processed by the API.");
        // refresh the list of users by calling the GET / users API
        getUsersAndPrint();
      })
      .catch(err =>{
        console.error("Error :", err);      
      });
       
    }
  });


function getUsersAndPrint() {
  //call the GET /users API to get all the registered users
  getData("/users",token)
  .then(response => {
    // The response is directly a JSON object !
      // No need to parse the string (deserialization)
      //let resp_json = JSON.parse(response);
      let resp_json = response;
      if (resp_json.success) {
        //$("#message_board").text(JSON.stringify(response.data)
        //clean the div
        $("#message_board").text("");

        //write some dynamic html content within the div
        let list = document.createElement("ul");
        let users_array = response.data;
        list.className = "list-group";
        for (let i = 0; i < users_array.length; i++) {
          //html_text += "<li>" + libraries[i] + "</li>";
          // to demonstrate the use of bootstrap and the List group
          var item = document.createElement("li");
          item.className = "list-group-item";
          item.innerText =
            users_array[i].fullname + " (" + users_array[i].email + ")";
          list.appendChild(item);
        }
        $("#message_board").append(list);
      } else {
        $("#message_board").text(JSON.stringify(response.error));
      }
  })
  .catch(err =>{
    console.error("Error :", err);      
  });  
}

$("#logout_btn").click(e => {
    //remove the token from localStorage
    localStorage.removeItem('token');
    token=undefined;
    //show the login component and hide others
    $("#login_component").show();
    //per default, hide the message board (to deal with error)
    if ($("#login_board").text() == "") $("#login_board").hide();
    //per default, hide the other components
    $("#register_component").hide();
    $("#view_users_component").hide();
});

});