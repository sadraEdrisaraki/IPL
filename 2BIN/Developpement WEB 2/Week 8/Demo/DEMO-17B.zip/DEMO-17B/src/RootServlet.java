import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
//import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
//import java.util.Random;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import com.auth0.jwt.JWTSigner;
import com.auth0.jwt.JWTVerifier;
import com.owlike.genson.GenericType;
import com.owlike.genson.Genson;

@SuppressWarnings("serial")
public class RootServlet extends HttpServlet {
	private static final String JWTSECRET = "mybigsecrete123";
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			// check if user has already logged in
			Object userID=null;
			Object ip=null;
			// check if user has already logged in
			String token = null; 
			Cookie[] cookies=req.getCookies();
			if (cookies != null) { 
			  for (Cookie c : cookies) { 
			    if ("token".equals(c.getName()) ) {
			      token = c.getValue(); 
			      Map<String, Object> decodedPayload = new JWTVerifier(JWTSECRET).verify(token); 
			      userID = decodedPayload.get("id");
			      ip = decodedPayload.get("ip");
			      
			      
			    } 
			  }
			}	
			
			//Object idUser=req.getSession().getAttribute("userId");
			
			
			
			if (userID!=null) {
				// OK, the user is already "authenticated", send him the users view
				String body;
				if (req.getRequestURI().contentEquals("/")) {
					System.out.println("AUTH:"+req.getRequestURI());
					body = new String(Files.readAllBytes(Paths.get("./views/users.html")));
					resp.setContentType("text/html");
					resp.setCharacterEncoding("utf-8");
					resp.setStatus(HttpServletResponse.SC_OK);
					resp.getWriter().write(body);
				} else
				//// else return the required file (there is a based folder named "public")
				{
					try {
						System.out.println("AUTH:"+req.getRequestURI());
						String fileContent = new String(Files.readAllBytes(Paths.get("public" + req.getRequestURI())));
						resp.setStatus(HttpServletResponse.SC_OK);
						resp.getWriter().write(fileContent);
					} catch (IOException e) {
						resp.getWriter().write("This ressource does not exist");
					}
				}				
			} else {
				// the user is not authenticated, send the login form
				if (req.getRequestURI().contentEquals("/")) {
					System.out.println("NOT AUTH:" + req.getRequestURI());
					resp.setContentType("text/html");
					resp.setCharacterEncoding("utf-8");
					// get the content of the file to be sent back to the client
					String body = new String(Files.readAllBytes(Paths.get("./views/login.html")));

					resp.setStatus(HttpServletResponse.SC_OK);
					resp.getWriter().write(body);
				} else
				//// else return the required file (there is a based folder named "public")
				{
					try {
						System.out.println("NOT AUTH:" + req.getRequestURI());
						String fileContent = new String(Files.readAllBytes(Paths.get("public" + req.getRequestURI())));
						resp.setStatus(HttpServletResponse.SC_OK);
						resp.getWriter().write(fileContent);
					} catch (IOException e) {
						resp.getWriter().write("This ressource does not exist");
					}
				}
			}
		}

		catch (Exception e) {
			e.printStackTrace();
			resp.setStatus(500);
			resp.setContentType("text/html");
			byte[] msgBytes = e.getMessage().getBytes("UTF-8");
			resp.setContentLength(msgBytes.length);
			resp.setCharacterEncoding("utf-8");
			resp.getOutputStream().write(msgBytes);
		}
	}

	// this POST method shall provide a personal message by redirecting to /welcome
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			System.out.println("CONNEC POST CALL");

			// get the parameters sent by the POST form
			String email = req.getParameter("email");
			String password = req.getParameter("password");
			if (password.equals("Logme")) {
				// user is authenticated, create a JWT
				Map<String, Object> claims = new HashMap<String, Object>(); 
				claims.put("id", UUID.randomUUID().toString()); 
				claims.put("ip", req.getRemoteAddr()); 
				String ltoken = new JWTSigner(JWTSECRET).sign(claims);
				System.out.println("New token generated :"+ltoken);
				
				
				//the token has been generated, save it in the cookie, and give  the name token to your cookie
				Cookie cookie = new Cookie("token", ltoken);
				cookie.setPath("/"); 
				//for security reason, don't allow JS to touch the cookie
				cookie.setHttpOnly(true);
				// expiration time of a cookie in seconds
				cookie.setMaxAge(60 * 60 * 24 * 365);
				resp.addCookie(cookie);	
	
				// send the users view
				// resp.sendRedirect("/users");
				String body = new String(Files.readAllBytes(Paths.get("./views/users.html")));
				resp.setContentType("text/html");
				resp.setCharacterEncoding("utf-8");
				resp.setStatus(HttpServletResponse.SC_OK);
				resp.getWriter().write(body);
			}
			else {
				// get the login HTML file "template" :			
				// use jsoup to load a document from a file:
				// https://jsoup.org/cookbook/input/load-document-from-file
				// use jsoup to parse the template
				File input = new File("views/login.html");
				Document login_template = Jsoup.parse(input, "UTF-8", "");
				// modify the div with id="message_board" :
				// https://jsoup.org/cookbook/modifying-data/set-html
				login_template.select("#message_board").html("Wrong password, please try again!");

				// Prepare the response
				resp.setContentType("text/html");
				resp.setCharacterEncoding("utf-8");
				resp.setStatus(HttpServletResponse.SC_OK);
				// get the html content from jsoup object
				resp.getWriter().write(login_template.html());
				}			
		}
		catch (Exception e) {
			e.printStackTrace();
			resp.setStatus(500);
			resp.setContentType("text/html");
			byte[] msgBytes = e.getMessage().getBytes("UTF-8");
			resp.setContentLength(msgBytes.length);
			resp.setCharacterEncoding("utf-8");
			resp.getOutputStream().write(msgBytes);
		}
	}

}
