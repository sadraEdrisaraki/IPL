"use strict";

import {Car} from "./car.js";

var btn = document.querySelector("button");
var msg = document.querySelector("div");

btn.onclick = function() {
  btn.innerText = "You clicked on me : )";
  var dacia = new Car("Dacia", "Sandero");
  msg.innerText = dacia.getDescription();
  
};



