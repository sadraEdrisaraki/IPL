const path = require('path');

//by default, webpack mode is production. You could test with development mode through the configuration file...
//or by using npm run dev or npm run build if you have configured package.json
module.exports = {
  //mode: 'development',
  entry: './src/index.js',
  output: {
    filename: 'main.js',
    path: path.resolve(__dirname, 'dist')
  }
};