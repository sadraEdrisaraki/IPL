"use strict";

// Import of a node.js package
const uniqid = require("uniqid");


class Student {
  constructor(firstname,lastname,orientation) {
    this.firstname = firstname.charAt(0).toUpperCase() + firstname.slice(1);  
    this.lastname = lastname.charAt(0).toUpperCase() + lastname.slice(1);
    this.orientation=orientation;
    // use of the uniqid package
    this.id = uniqid();
  }
  
  details() {
    const details="Hello, my name is " + this.firstname  + " " + this.lastname  + ", my orientation is:" + this.orientation + ", my ID is: " + this.id;
    console.log(details);
    return details;
  }
}

// Test of the script with node.js
/*var raphael = new Student("raphael","baroni","IT");
var paloma = new Student("paloma","jeans","Library");

raphael.details();
paloma.details();*/

// Named export (to be commented when testing this script with Node.js)
export default Student;