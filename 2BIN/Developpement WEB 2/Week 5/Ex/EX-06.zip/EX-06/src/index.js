"use strict";

import Student from "./student";

let form = document.querySelector("#myForm");
let msg = document.querySelector("#message_board");
let students=[];

form.addEventListener('submit', function(e) {
  // prevent default behaviour (event bubling up)
  e.preventDefault();

  // add a student to the students array
  let firstname = document.getElementById("firstname");
  let lastname = document.getElementById("lastname");
  let orientation = document.getElementById("orientation");
  const current_item = new Student(firstname.value,lastname.value,orientation.value);
  students.push(current_item);

  // make the message_board div visible : remove associate "invisible" bootstrap class
  msg.classList.remove("invisible");

  // add the last item to the board (by calling the detail() method of a student)
  const student_div = document.createElement("div");
  student_div.innerText = current_item.details();
  student_div.className = "alert alert-success";
  
  msg.append(student_div); 
  
  // reset our form inputs;
  firstname.value="";
  lastname.value="";
  orientation.value="";

});



