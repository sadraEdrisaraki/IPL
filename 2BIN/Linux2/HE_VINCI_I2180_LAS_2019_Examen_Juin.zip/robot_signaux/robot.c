#include <stdbool.h>
#include <stdio.h>

#include <signal.h>

#include <sys/types.h>

#include <unistd.h>

#include "utils.h"

#define MAX_Y  10

//***************************************************************************
// CHILD CODE
//***************************************************************************

int signum;

void handler(int num) {
}

void run() {
}

//***************************************************************************
// PARENT CODE
//***************************************************************************

int main () {
	pid_t chid = fork_and_run0(run);
}

