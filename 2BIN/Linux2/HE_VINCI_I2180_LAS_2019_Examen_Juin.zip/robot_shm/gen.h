#ifndef _GEN_H_
#define _GEN_H_

#define SHM_KEY 1234
#define SEM_KEY 4567
#define PERM 0666

#endif