#include <stdio.h>

#include "gen.h"
#include "utils.h"

#define MAX_X  10
#define MAX_Y  10

//******************************************************************************
// MAIN FUNCTION
//******************************************************************************
int main (int argc, char *argv[]) {
}